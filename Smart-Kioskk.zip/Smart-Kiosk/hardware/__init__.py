# hardware package initializer
# allows: from hardware.gpio_manager import GPIOManager
